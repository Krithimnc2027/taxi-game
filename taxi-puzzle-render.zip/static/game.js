let boardSize = 5;
let grid = [];
let selected = null;
let moves = 0;
let startTime = null;
let timerInterval = null;

const board = document.getElementById('game-board');
const status = document.getElementById('status');
const gridSizeSelect = document.getElementById('grid-size');
const difficultySelect = document.getElementById('difficulty');
const startBtn = document.getElementById('start-btn');
const solveBtn = document.getElementById('solve-btn');

startBtn.addEventListener('click', startGame);
solveBtn.addEventListener('click', solvePuzzle);

function startGame() {
  boardSize = parseInt(gridSizeSelect.value);
  const difficulty = difficultySelect.value;
  moves = 0;
  selected = null;

  if (timerInterval) clearInterval(timerInterval);
  startTime = Date.now();
  timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    status.textContent = `Moves: ${moves} | Time: ${elapsed}s`;
  }, 1000);

  grid = Array.from({ length: boardSize }, () =>
    Array.from({ length: boardSize }, () => '')
  );

  grid[0][0] = 'taxi';
  grid[boardSize - 1][boardSize - 1] = 'depot';

  if (difficulty !== 'easy') {
    placeObstacles(difficulty);
  }

  while (!findPath()) {
    startGame();
    return;
  }

  status.textContent = `Moves: ${moves} | Time: 0s`;
  drawBoard();
}

function placeObstacles(difficulty) {
  let maxObs = difficulty === 'medium' ? 2 : boardSize * 2;
  let placed = 0;
  while (placed < maxObs) {
    let r = Math.floor(Math.random() * boardSize);
    let c = Math.floor(Math.random() * boardSize);
    if (grid[r][c] === '') {
      grid[r][c] = 'obstacle';
      placed++;
    }
  }
}

function drawBoard(path = []) {
  board.innerHTML = '';
  board.style.gridTemplateColumns = `repeat(${boardSize}, 60px)`;
  board.style.gridTemplateRows = `repeat(${boardSize}, 60px)`;

  for (let r = 0; r < boardSize; r++) {
    for (let c = 0; c < boardSize; c++) {
      const cell = document.createElement('div');
      cell.classList.add('cell');
      const cellVal = grid[r][c];
      if (cellVal === 'taxi') cell.classList.add('taxi');
      if (cellVal === 'depot') cell.classList.add('depot');
      if (cellVal === 'obstacle') cell.classList.add('obstacle');
      if (selected && selected[0] === r && selected[1] === c)
        cell.classList.add('selected');

      const pathIndex = path.findIndex(([pr, pc]) => pr === r && pc === c);
      if (pathIndex !== -1 && cellVal === '') {
        cell.classList.add('path-step');
        cell.textContent = pathIndex + 1;
      }

      cell.addEventListener('click', () => selectCell(r, c));
      board.appendChild(cell);
    }
  }
}

function selectCell(r, c) {
  if (grid[r][c] === 'taxi') {
    selected = [r, c];
  } else if (selected) {
    const [sr, sc] = selected;
    if (
      Math.abs(sr - r) + Math.abs(sc - c) === 1 &&
      (grid[r][c] === '' || grid[r][c] === 'depot')
    ) {
      grid[r][c] = 'taxi';
      grid[sr][sc] = '';
      selected = [r, c];
      moves++;
      status.textContent = `Moves: ${moves}`;
      checkWin();
    }
  }
  drawBoard();
}

function checkWin() {
  for (let r = 0; r < boardSize; r++) {
    for (let c = 0; c < boardSize; c++) {
      if (grid[r][c] === 'taxi' && (r !== boardSize - 1 || c !== boardSize - 1)) {
        return;
      }
    }
  }

  if (timerInterval) clearInterval(timerInterval);
  const elapsed = Math.floor((Date.now() - startTime) / 1000);
  alert(`🎉 You won in ${moves} moves and ${elapsed} seconds!`);

  let username = prompt("Enter your username to save your best time:");
  if (!username) return;

  const payload = {
    username: username,
    time: elapsed,
    gridSize: boardSize,
    level: difficultySelect.value
  };

  fetch("http://127.0.0.1:8000/submit_time", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  })
  .then(response => response.json())
  .then(data => {
    if (data.error) {
      alert("Error: " + data.error);
    } else {
      alert("Best times saved successfully!");
      showUserBestTimes(username);
    }
  })
  .catch(err => {
    alert("Failed to submit time: " + err.message);
  });
}

function showUserBestTimes(username) {
  fetch(`http://127.0.0.1:8000/leaderboard/${username}`)
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        alert("No scores found.");
        return;
      }

      let message = `🏆 ${data.username}'s Best Times:\n`;
      for (let key in data.best_scores) {
        message += `${key}: ${data.best_scores[key]}s\n`;
      }
      alert(message);
    })
    .catch(err => {
      alert("Failed to load best scores: " + err.message);
    });
}

function showGlobalLeaderboard() {
  fetch("http://127.0.0.1:8000/leaderboard")
    .then(res => res.json())
    .then(data => {
      let text = "🏆 Global Leaderboard:\n";
      data.forEach(entry => {
        text += `${entry.username} - ${entry.grid_level}: ${entry.best_time}s\n`;
      });
      alert(text);
    })
    .catch(err => {
      alert("Error loading leaderboard: " + err.message);
    });
}

function solvePuzzle() {
  const path = findPath();
  if (path) {
    drawBoard(path.slice(1)); // skip start cell
  } else {
    alert('No path to depot found.');
  }
}

function findPath() {
  const start = [0, 0];
  const goal = [boardSize - 1, boardSize - 1];
  const queue = [[start]];
  const visited = new Set([start.toString()]);

  while (queue.length > 0) {
    const path = queue.shift();
    const [r, c] = path[path.length - 1];

    if (r === goal[0] && c === goal[1]) {
      return path;
    }

    for (const [dr, dc] of [
      [0, 1], [1, 0], [0, -1], [-1, 0]
    ]) {
      const nr = r + dr;
      const nc = c + dc;
      if (
        nr >= 0 && nr < boardSize &&
        nc >= 0 && nc < boardSize &&
        grid[nr][nc] !== 'obstacle' &&
        !visited.has([nr, nc].toString())
      ) {
        visited.add([nr, nc].toString());
        queue.push([...path, [nr, nc]]);
      }
    }
  }
  return null;
}

startGame();

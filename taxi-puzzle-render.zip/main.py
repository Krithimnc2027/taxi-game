from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for testing; restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve frontend files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Serve index.html at root
@app.get("/")
def root():
    return FileResponse("static/index.html")

# Backend storage
times = {}

@app.post("/submit_time")
def submit_time(data: dict):
    username = data.get("username")
    time = data.get("time")
    grid_size = data.get("gridSize")
    level = data.get("level")

    if not username or time is None or not grid_size or not level:
        return {"error": "Missing required fields"}

    key = f"{grid_size}-{level}"
    user_scores = times.setdefault(username, {})

    if key not in user_scores or time < user_scores[key]:
        user_scores[key] = time

    return {"message": "Time submitted successfully", "best_times": user_scores}

@app.get("/leaderboard/{username}")
def get_user_scores(username: str):
    if username not in times:
        return {"error": "User not found"}
    return {"username": username, "best_scores": times[username]}

@app.get("/leaderboard")
def get_leaderboard():
    leaderboard = []
    for username, scores in times.items():
        for key, time in scores.items():
            leaderboard.append({
                "username": username,
                "grid_level": key,
                "best_time": time
            })
    return sorted(leaderboard, key=lambda x: x["best_time"])
